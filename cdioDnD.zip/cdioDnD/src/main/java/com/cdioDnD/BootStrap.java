package com.cdioDnD;

import com.cdioDnD.controller.Context;
import com.cdioDnD.controller.StartState;

public class BootStrap {



    public static void main(String[] args){

        Context context = new Context();


    }
}
