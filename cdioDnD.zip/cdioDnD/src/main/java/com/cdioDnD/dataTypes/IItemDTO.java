package com.cdioDnD.dataTypes;

public interface IItemDTO {
//id
    int getID();
    void setID(int id);

//name
    String getName();
    void setName(String name);


    double getWeight();
    void setWeight(double weight);

    String getDescription();
    void setDescription(String description);


}
